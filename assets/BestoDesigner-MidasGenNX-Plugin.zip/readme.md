# BESTOBEAM Designer

MIDAS GEN용 BESTO 합성보 설계 플러그인입니다. 단면 또는 선택 부재를 기준으로 만족 단면을 검색하고, 결과를 GEN에 반영합니다.

**사용**
1. **Section**에서 단면을 고르거나, **Member**에서 부재 1개를 선택한 뒤 **Refresh**합니다.
2. Additional Informations를 확인한 뒤 **Search Satisfied Section**으로 검색합니다.
3. **Detail**에서 결과를 확인하고, **Design**에서 치수를 수정한 뒤, **Save**로 왼쪽 Update List에 넣습니다.
4. 여러 단면을 저장한 뒤 Update List의 **Change**로 한 번에 모델에 반영합니다. SEL은 저장한 설계를 다시 불러오고, **Delete**는 행을 지웁니다.

해석이 필요하면 GEN에서 해석 후 Refresh합니다.
